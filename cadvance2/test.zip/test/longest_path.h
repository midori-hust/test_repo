#ifndef __LONGEST_PATH_H__
#define __LONGEST_PATH_H__

#include "directed_graph.h"

int longestPath(Graph graph, int source, int target, int *path, int *length);

/* Private */

#endif