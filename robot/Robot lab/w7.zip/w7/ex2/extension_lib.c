#include "extension_lib.h"

int solve() {
	PhoneBook *book = NULL;

	book = createPhoneBook();
	addPhoneNumber(12345677, "blah blah", book);
	printf("%s\n", getPhoneNumber(12345677, book));

	dropPhoneBook(book);
	return 0;
}