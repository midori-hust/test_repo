#include "extension_lib.h"

void printArray(String *a, int amount) {
	int i;

	for(i = 0; i < amount; i++) {
		printf("%s\n", a[i].content);
		if(i % 25 == 0 && i != 0) {
			printf("Do you want to see more 25 lines? (Y N)\n");
			if(getContinueRequest() == 'Y') {
				continue;
			} else {
				break;
			}
		}

	}
}

int solve(FILE *f_domain, FILE *f_user, FILE *fout1, FILE *fout2) {
	String *emailList, *result;
	int rows;

	if((emailList = myMalloc(sizeof(String), MAXSIZE)) == NULL) {
		return 1;
	}

	if((result = myMalloc(sizeof(String), MAXSIZE)) == NULL) {
		return 1;
	}

	if(!genEmailList(emailList, MAXSIZE, f_domain, f_user)) {
		return 1;
	}



	// sort(emailList, 0, MAXSIZE - 1);
	q3sort(emailList, sizeof(String), 0, MAXSIZE - 1, myStringCompare);
	printToFile(fout1, "%s\n", emailList, MAXSIZE);
	printf("Sort successfully\n");
	printf("The email list before removing duplicated emails: \n");
	printArray(emailList, MAXSIZE); // Debugging

	rows = removeDuplicatedEmail(result, emailList, MAXSIZE);

	// printArray(result, rows); // Debugging
	printToFile(fout2, "%s\n", result, rows);
	printf("Print to file successfully\n");
	
	free(emailList);
	free(result);
	return 0;
}

int genEmailList(String *emailList, int amount, FILE *f_domain, FILE *f_user) {
	String *domainList, *userList;
	int i;
	int domainListSize = getTheNumberOfRowInFile(f_domain);
	int userListSize = getTheNumberOfRowInFile(f_user);

	if((domainList = myMalloc(sizeof(String), domainListSize)) == NULL)
		return 0;

	if((userList = myMalloc(sizeof(String), getTheNumberOfRowInFile(f_user))) == NULL)
		return 0;

	i = 0;
	while(fscanf(f_domain, "%s\n", domainList[i++].content) != EOF);
	
	i = 0;
	while(fscanf(f_user, "%s\n", userList[i++].content) != EOF);
	
	srand(time(NULL));

	for(i = 0; i < amount; i++) {
		sprintf(emailList[i].content, "%s@%s", userList[rand() % userListSize].content, domainList[rand() % domainListSize].content);
	}

	free(domainList);
	free(userList);
	return 1;
}

int removeDuplicatedEmail(String* result, String* emailList, int amount) {
	int i, n = 0;

	if(amount == 1)
		return 1;
	if(result == NULL)
		return -1;
	if(emailList == NULL)
		return -1;

	strcpy(result[n++].content, emailList[0].content);

	for(i = 1; i < amount; i++) {
		if(strcmp(emailList[i-1].content, emailList[i].content) != 0) {
			strcpy(result[n++].content, emailList[i].content);
		}
	}

	return n;
}

/* Compare functions */
int myIntCompare(void const* a, void const* b) {
	const int* x = (const int*) a;
	const int* y = (const int*) b;

	if(*x == *y)
		return 0;

	return *x > *y ? 1 : -1;
}

int myStringCompare(void const* a, void const* b) {
	const String* x = (const String*) a;
	const String* y = (const String*) b;

	return strcmp(x->content, y->content); // Find the student name
}

// int compareStudent(void const *a, void const *b) {
// 	const Student* x = (const Student*)a;
// 	const Student* y = (const Student*)b;

// 	if(x->id == y->id)
// 		return 0;

// 	return x->id > y->id ? 1 : -1;
// }

int mySearch(void *buf, int size, int total, void *item, int (*compare)(void const*, void const*)) {
	int i, res;

	if(total == 0 || size < 0 || buf == NULL)
		return -1; // Cannot find the item element

	for(i = 0; i < total; i++) {
		res = compare(item, (char*)buf + (size * i));
		if(res == 0)
			return i;
	}

	return -1;
}

void printList(void *a, size_t total, char *pattern, void (*printPattern)(void* buf, char *pattern, size_t total)) {
	printPattern(a, pattern, total);
}

// void myPrintPattern(void *buf, char *pattern, size_t total) {
// 	int i;
// 	Student *a = (Student*)buf;

// 	for(i = 0; i < total; i++) {
// 		printf(pattern, i, a[i].id, a[i].name);
// 	}
// }

// int findMinCompare(void const* x, void const* y) {
// 	const Student* a = (const Student*)x;
// 	const Student* b = (const Student*)y;

// 	if(a->id == b->id)
// 		return 0;

// 	return a->id > b->id ? 1 : -1;
// }


// int findMaxCompare(void const* x, void const* y) {
// 	const Student* a = (const Student*)x;
// 	const Student* b = (const Student*)y;

// 	if(a->id == b->id)
// 		return 0;

// 	return a->id > b->id ? -1 : 1;
// }
