#include "EchoServer.h"

int checkAccount(char *id, char *password) {
	
	return 1; //Exist account which has this id and password
}