#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define ECHOMAX 255     /* Do dai xau dai nhat */

void DieWithError(char *errorMessage);  /* Ham kiem soat loi*/

int main()
{
    int sock,i;                        /* Socket */
    struct sockaddr_in echoServAddr; /* Dia chi Server */
    struct sockaddr_in echoClntAddr; /* Dia chi Client */
    unsigned int cliAddrLen;         /* Do dai xau nhan */
    char echoBuffer[ECHOMAX];        /* Bo nho dem */
    unsigned short echoServPort;     /* Server port */
    int recvMsgSize;                 /* Size of received message */

    echoServPort = 5000;

    /* Tao Socket */
    sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);

    /* Construct local address structure */
    memset(&echoServAddr, 0, sizeof(echoServAddr));   /* Zero out structure */
    echoServAddr.sin_family = AF_INET;                /* Internet address family */
    echoServAddr.sin_addr.s_addr = htonl(INADDR_ANY); /* Any incoming interface */
    echoServAddr.sin_port = htons(echoServPort);      /* Local port */

    /* Bind to the local address */
    bind(sock, (struct sockaddr *) &echoServAddr, sizeof(echoServAddr));

    for (;;)
    {
        /* Set the size of the in-out parameter */
        cliAddrLen = sizeof(echoClntAddr);

        /* Block until receive message from a client */
        if ((recvMsgSize = recvfrom(sock, echoBuffer, ECHOMAX, 0,
            (struct sockaddr *) &echoClntAddr, &cliAddrLen)) < 0)
            DieWithError("recvfrom() failed");

        printf("Handling client %s\n", inet_ntoa(echoClntAddr.sin_addr));

        /* Send received datagram back to the client */
        if (sendto(sock, echoBuffer, recvMsgSize, 0,
             (struct sockaddr *) &echoClntAddr, sizeof(echoClntAddr)) != recvMsgSize)
            DieWithError("sendto() sent a different number of bytes than expected");
    }

}
void DieWithError(char *errorMessage)
{
    perror(errorMessage);
    exit(1);
}
