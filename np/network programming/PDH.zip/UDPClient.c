#include <stdio.h>
#include <sys/socket.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <signal.h>

#define ECHOMAX 255


void DieWithError(char *errorMessage);

int main()
{
    int sock,i;                    
    struct sockaddr_in echoServAddr;
    struct sockaddr_in fromAddr;    
    unsigned short echoServPort;
    unsigned int fromSize;
    char *servIP;
    char *echoString;
    char echoBuffer[ECHOMAX+1];
    int echoStringLen;
    int respStringLen;


    servIP = "192.168.1.3";
    echoString = "Pham Duy Hung, 10/10/1991, 20091387";
    echoStringLen = strlen(echoString);
    echoServPort = 5000;


    sock = socket(PF_INET, SOCK_DGRAM, IPPROTO_UDP);

    
    memset(&echoServAddr, 0, sizeof(echoServAddr)); 
    echoServAddr.sin_family = AF_INET;
    echoServAddr.sin_addr.s_addr = inet_addr(servIP);
    echoServAddr.sin_port   = htons(echoServPort);



    for(i=0;i<100;)
    {
    sendto(sock, echoString, echoStringLen, 0, (struct sockaddr *) &echoServAddr, sizeof(echoServAddr));
    fromSize = sizeof(fromAddr);
    if ((respStringLen = recvfrom(sock, echoBuffer, ECHOMAX, 0,
         (struct sockaddr *) &fromAddr, &fromSize)) != echoStringLen)
        DieWithError("recvfrom() failed");

    if (echoServAddr.sin_addr.s_addr != fromAddr.sin_addr.s_addr)
    {
        fprintf(stderr,"Error: received a packet from unknown source.\n");
        exit(1);
    }
    i=i+1;
    }
  
    echoBuffer[respStringLen] = '\0';
    printf("Received: %s\n", echoBuffer);

    close(sock);
    exit(0);
}
void DieWithError(char *errorMessage)
{
    perror(errorMessage);
    exit(1);
}
