#include "library.h"

int main() {

	if(solve()) {
		printf("Error occurs when executing program\n");
		return 1;
	}

	return 0;
}