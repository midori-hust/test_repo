#include "lib.h"

int main() {
	if(solve()) {
		printf("Error occurs when excute program\n");
		return 1;
	}

	return 0;
}