void swwap(int , int );
